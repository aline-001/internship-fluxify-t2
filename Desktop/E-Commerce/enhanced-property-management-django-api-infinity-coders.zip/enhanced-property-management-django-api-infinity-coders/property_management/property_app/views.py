from django.shortcuts import render, HttpResponseRedirect
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.decorators import login_required
from property_app.models import User
from property_app.models import Property, Units, Tenant, Lease
from .serializers import PropertySerializer, UnitSerializer, TenantSerializer, LeaseSerializer
from .forms import *
from django.db.models import Q, QuerySet
from .models import *
from .models import Property, Units,Tenant
from django.shortcuts import render, get_object_or_404,redirect
from django.contrib import messages





@api_view(['GET', 'POST'])
def property_list(request):
    if request.method == 'GET':
        properties = Property.objects.all()
        serializer = PropertySerializer(properties, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = PropertySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def property_detail(request, pk):
    try:
        property_instance = Property.objects.get(pk=pk)
    except Property.DoesNotExist:
        return Response({'error': 'Property not found'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = PropertySerializer(property_instance)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = PropertySerializer(property_instance, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        property_instance.delete()
        return Response({'message': 'Property deleted'}, status=status.HTTP_204_NO_CONTENT)


@api_view(['GET', 'POST'])
def unit_list(request):
    if request.method == 'GET':
        units = Units.objects.all()
        serializer = UnitSerializer(units, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = UnitSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def unit_detail(request, pk):
    if request.method == 'GET':
        unit_instance = Units.objects.get(Units, pk=pk)
        serializer = UnitSerializer(unit_instance)
        return Response(serializer.data)

    elif request.method == 'PUT':
        unit_instance = Units.objects.filter(Units, pk=pk)
        serializer = UnitSerializer(unit_instance, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        unit_instance = Units.objects.filter(Units, pk=pk)
        unit_instance.delete()
        return Response({'message': 'Unit deleted'}, status=status.HTTP_204_NO_CONTENT)


@api_view(['GET', 'POST'])
def tenant_list(request):
    if request.method == 'GET':
        tenants = Tenant.objects.all()
        serializer = TenantSerializer(tenants, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        serializer = TenantSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def tenant_detail(request, pk):
    try:
        tenant_instance = Tenant.objects.get(pk=pk)
    except Tenant.DoesNotExist:
        return Response({'error': 'Tenant not found'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = TenantSerializer(tenant_instance)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = TenantSerializer(tenant_instance, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        tenant_instance.delete()
        return Response({'message': 'Tenant deleted'}, status=status.HTTP_204_NO_CONTENT)


@api_view(['GET', 'POST'])
def lease_list(request):
    if request.method == 'GET':
        leases = Lease.objects.all()
        serializer = LeaseSerializer(leases, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = LeaseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def lease_detail(request, pk):
    try:
        lease_instance = Lease.objects.get(pk=pk)
    except Lease.DoesNotExist:
        return Response({'error': 'Lease not found'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = LeaseSerializer(lease_instance)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = LeaseSerializer(lease_instance, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        lease_instance.delete()
        return Response({'message': 'Lease deleted'}, status=status.HTTP_204_NO_CONTENT)


def home_views(request):
    properties = Property.objects.all()
    context = {'properties': properties}
    return render(request, 'home.html', context)


def proForm(request):
    form = PropertyForm()
    submitted = False
    if request.method == 'POST':
        form = PropertyForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
        else:
            form = PropertyForm(request.GET)
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'property_form.html', {'form': form})


def property_lists(request):
    properties = Property.objects.all()  # Get all properties
    return render(request, 'property_list.html', {'properties': properties})


def tenant_lists(request):
    tenant = Tenant.objects.filter() # Safely fetch the tenant
    return render(request, 'tenant_list.html', {'tenant': tenant})


def lease_lists(request):
    leases = Lease.objects.all()
    return render(request, 'lease_list.html', {'leases': leases})


def edit_property(request, pk):
    property_instance = get_object_or_404(Property, pk=pk)

    if request.method == 'POST':
        form = PropertyForm(request.POST, request.FILES, instance=property_instance)
        if form.is_valid():
            form.save()
            return redirect('property_detail', pk=property_instance.pk)  # Redirect to property detail after saving
    else:
        form = PropertyForm(instance=property_instance)

    return render(request, 'edit_property.html', {'form': form, 'property': property_instance})

def edit_tenant(request, tenant_id):
    tenant = get_object_or_404(Tenant, id=tenant_id)

    if request.method == 'POST':
        form = TenantForm(request.POST, instance=tenant)
        if form.is_valid():
            form.save()
            return redirect('tenant_lists')
    else:
        form = TenantForm(instance=tenant)

    context = {
        'form': form,
        'tenant': tenant
    }
    return render(request, 'edit_tenant.html', context)



def tenaForm(request):
    form = TenantForm()
    submitted = False
    if request.method == 'POST':
        form = TenantForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
        else:
            form = TenantForm(request.GET)
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'tenant_form.html', {'form': form})


def unitForm(request):
    form = UnitsForm()
    submitted = False
    if request.method == 'POST':
        form = UnitForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
        else:
            form = PropertyForm(request.GET)
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'unit_form.html', {'form': form})


def leaseForm(request):
    form = LeaseForm()
    submitted = False
    if request.method == 'POST':
        form = LeaseForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('?submitted=True')
        else:
            form = PropertyForm(request.GET)
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'lease_form.html', {'form': form})


def houseOneDetails(request, pk):
    property = get_object_or_404(Property, id=property_id, landlord=request.user)
    tenants = property.tenants.all()
    leases = property.leases.all()
    return render(request, 'houseOneDetails.html.html', {'property': property, 'tenants': tenants, 'leases': leases})


def home(request):
    # prop = Property.objects.all()
    # context = {'prop': prop}
    # if search := request.GET.get('search'):
    #     q = Property.objects.filter(name__icontains=search)
    #     context['prop'] = q
    #     context['search'] = search
    # return render(request, 'home.html', context)
    properties = Property.objects.all()
    context = {'properties': properties}
    if search := request.GET.get('search'):
        q = Property.objects.filter(name__icontains=search)
        context['properties'] = q
        context['search'] = search
        if not q:
            properties: QuerySet[Property] = Property.objects.all()
            context['properties'] = properties
            context['search'] = ''
    return render(request, 'home.html', context)


def get_users(request):
    users = User.objects.all()
    return render(request, 'users.html', {'users': users})


def dashboards(request):
    properties = Property.objects.all()
    units = Unit.objects.all()
    tenants = Tenant.objects.all()
    leases = Lease.objects.all()

    # Calculating key metrics
    total_properties = properties.count()
    total_units = units.count()
    total_tenants = tenants.count()
    total_leases = leases.count()

    # Calculate occupancy rate
    occupied_units = units.filter(is_available=False).count()
    occupancy_rate = (occupied_units / total_units * 100) if total_units > 0 else 0

    # Calculate total revenue based on leases
    total_revenue = sum(lease.amount for lease in leases)

    # Create context for rendering
    context = {
        'total_properties': total_properties,
        'total_units': total_units,
        'total_tenants': total_tenants,
        'total_leases': total_leases,
        'occupancy_rate': occupancy_rate,
        'total_revenue': total_revenue,
        'properties': properties,
        'units': units,
        'tenants': tenants,
        'leases': leases,
    }

    return render(request, 'admin_dashboards.html', context)


def admin_dashboard(request):
    properties = Property.objects.all()
    units = Units.objects.all()
    tenants = Tenant.objects.all()
    leases = Lease.objects.all()
    total_properties = properties.count()
    total_units = units.count()
    total_tenants = tenants.count()
    total_leases = leases.count()

    # Calculate occupancy rate
    occupied_units = units.filter(is_available=False).count()
    occupancy_rate = (occupied_units / total_units * 100) if total_units > 0 else 0

    # Calculate total revenue based on leases
    total_revenue = sum(lease.amount for lease in leases)

    # Create context for rendering

    context = {
        'properties_count': properties.count(),
        'units_count': units.count(),
        'tenants_count': tenants.count(),
        'leases_count': leases.count(),
        'properties': properties,
    }
    return render(request, 'admin_dashboard.html', context)


def landlord_dashboard(request):
    user = request.user
    properties = Property.objects.filter(landlord=user)
    tenants = Tenant.objects.filter(property__in=properties)
    leases = Lease.objects.filter(property__in=properties)

    context = {
        'properties': properties,
        'tenants': tenants,
        'leases': leases,
    }
    return render(request, 'landlord_dashboard.html', context)


def send_message_to_landlord(request):
    if request.method == "POST":
        tenant = Tenant.objects.get(user=request.user)  # Assuming a user field links the Tenant
        message_content = request.POST.get('message')

        if message_content:
            # Save the message to the database
            LandlordMessage.objects.create(
                tenant=tenant,
                landlord=tenant.lease.property.landlord,  # Assuming the Lease links to a Property and Landlord
                message=message_content
            )
            messages.success(request, "Your message has been sent successfully!")
        else:
            messages.error(request, "Message cannot be empty.")
        return redirect('tenant_dashboard')  # Redirect back to the tenant dashboard
    else:
        messages.error(request, "Invalid request method.")
        return redirect('tenant_dashboard')


def tenant_dashboard(request):
        # Example logic to fetch tenant-specific data
        tenant = Tenant.objects.get(user=request.user)
        lease = Lease.objects.filter(tenant=tenant).first()
        context = {
            'tenant': tenant,
            'lease': lease,
            'maintenance_requests': tenant.maintenance_requests.all(),  # Example related field
        }
        return render(request, 'tenant_dashboard.html', context)


def dashboards(request):
    properties = Property.objects.all()
    units = Units.objects.all()
    tenants = Tenant.objects.all()
    leases = Lease.objects.all()

    # Calculating key metrics
    total_properties = properties.count()
    total_units = units.count()
    total_tenants = tenants.count()
    total_leases = leases.count()

    # Calculate occupancy rate
    occupied_units = units.filter(is_available=False).count()
    occupancy_rate = (occupied_units / total_units * 100) if total_units > 0 else 0

    # Calculate total revenue based on leases
    total_revenue = sum(lease.amount for lease in leases)

    # Create context for rendering
    context = {
        'total_properties': total_properties,
        'total_units': total_units,
        'total_tenants': total_tenants,
        'total_leases': total_leases,
        'occupancy_rate': occupancy_rate,
        'total_revenue': total_revenue,
        'properties': properties,
        'units': units,
        'tenants': tenants,
        'leases': leases,
    }

    return render(request, 'admin_dashboard.html', context)


def property_dashboard(request):

    # Calculate statistics
    total_properties = Property.objects.count()
    total_units = Units.objects.count()
    occupied_units = Units.objects.filter(lease__isnull=False).count()
    available_units = Units.objects.filter(is_available=True).count()

    # Calculate occupancy rate
    if total_units > 0:
        occupancy_rate = (occupied_units / total_units) * 100
    else:
        occupancy_rate = 0  # Avoid division by zero

    context = {
        'total_properties': total_properties,
        'total_units': total_units,
        'occupied_units': occupied_units,
        'available_units': available_units,
        'occupancy_rate': occupancy_rate,
    }

    return render(request, 'properties_dashboard.html', context)


@login_required
def messaging_view(request):
    a = Contact.objects.all()
    return render(request, 'messages.html', {'a': a})


def prop(request):
    a = Property.objects.all()
    return render(request, 'propertymgt.html', {'a': a})


def ten(request):
    a = Tenant.objects.all()
    return render(request, 'tenantmgt.html', {'a': a})


@login_required
def user_management(request):
    # if not request.user.is_staff:
    #     return redirect('login')  # Only staff can access this page
    users = User.objects.all()
    return render(request, 'users.html', {'users': users})


@login_required
def toggle_activation(request, user_id):
    if not request.user.is_staff:
        return redirect('login')
    user = get_object_or_404(User, id=user_id)
    user.is_active = not user.is_active
    user.save()
    messages.success(request, f"User {user.username} activation status changed.")
    return redirect('user_management')


@login_required
def toggle_admin(request, user_id):
    if not request.user.is_staff:
        return redirect('login')
    user = get_object_or_404(User, id=user_id)
    user.is_staff = not user.is_staff
    user.save()
    messages.success(request, f"User {user.username} admin status changed.")
    return redirect('user_management')


@login_required
def delete_user(request, user_id):
    if not request.user.is_staff:
        return redirect('login')
    user = get_object_or_404(User, id=user_id)
    if user == request.user:
        messages.error(request, "You cannot delete yourself.")
    else:
        user.delete()
        messages.success(request, f"User {user.username} deleted.")
    return redirect('user_management')


@login_required
def add_user(request):
    if not request.user.is_staff:
        return redirect('login')
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
        else:
            User.objects.create_user(username=username, email=email, password=password)
            messages.success(request, f"User {username} added.")
        return redirect('user_management')
    return redirect('user_management')

def register(request):
    form = UserCreationForm()
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created successfully')
            return redirect('login_user')
    else:
        form = UserCreationForm()
    context = {'form': form}
    return render(request, 'signup.html', context)


def login_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid credentials')

    return render(request, 'login.html', {})
