from enum import unique

from django.db import models
from django.contrib.auth.models import AbstractUser



class User(AbstractUser):
    pass

    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('landlord', 'Landlord'),
        ('tenant', 'Tenant'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='tenant')

    def _str_(self):
        return self.username

property_type=[
    ('apartment', 'Apartment'),
    ('house', 'House'),
    ('commercial', 'Commercial'),
    ("Land", "Land"),
]

class Property(models.Model):
    name = models.CharField(max_length=200)
    image = models.ImageField(upload_to='images/', null=True, blank=True,unique=True)
    address=models.CharField(max_length=200)
    type=models.CharField(max_length=20,choices=property_type)
    description=models.TextField(max_length=200)
    number_of_units=models.IntegerField()

    def __str__(self):
        return self.name


class Units(models.Model):
    property=models.ForeignKey(Property,on_delete=models.CASCADE)
    unit_number=models.CharField(max_length=100,unique=True)
    bedrooms=models.IntegerField()
    bathrooms=models.IntegerField()
    rent=models.IntegerField()
    is_available=models.BooleanField(default=True)
    is_occupied=models.BooleanField(default=False)

    def __str__(self):
        return f"{self.unit_number} -- {self.property.name}"

class Tenant(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE,null=True,blank=True)
    name=models.CharField(max_length=200,unique=True)
    email=models.EmailField(unique=True)
    phone_number=models.CharField(max_length=20)

    def __str__(self):
        return self.name

class Lease(models.Model):
    tenant=models.ForeignKey(Tenant, on_delete=models.CASCADE)
    unit=models.ForeignKey(Units ,on_delete=models.CASCADE)
    start_date=models.DateField()
    end_date=models.DateField()
    rent_amount=models.IntegerField()

    def __str__(self):
        return f"{self.tenant.name}"

class Landlord(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class LandlordMessage(models.Model):
    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE, related_name='messages')
    landlord = models.ForeignKey(Landlord, on_delete=models.CASCADE, related_name='messages')
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.tenant.name} to {self.landlord.name}"

