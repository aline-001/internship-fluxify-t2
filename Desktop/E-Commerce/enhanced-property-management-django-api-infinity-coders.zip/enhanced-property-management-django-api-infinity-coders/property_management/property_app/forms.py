from django import forms
from .models import *
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm


class PropertyForm(ModelForm):
    class Meta:
        model = Property
        fields = ['name', 'image', 'address', 'type', 'description', 'number_of_units']


class UnitsForm(ModelForm):
    class Meta:
        model = Units
        fields = ['unit_number', 'bedrooms', 'bathrooms', 'rent', 'is_available']


class TenantForm(ModelForm):
    class Meta:
        model = Tenant
        fields = ['name', 'email', 'phone_number']


class LeaseForm(ModelForm):
    class Meta:
        model = Lease
        fields = ['tenant', 'unit', 'start_date', 'end_date', 'rent_amount']


class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
