"""
URL configuration for property_management project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.Home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib.auth import views as auth_views
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from property_app.views import *
from django.contrib.auth import views as auth_views
from django.contrib.auth import get_user_model
from django.urls import reverse_lazy
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('property_app.urls')),
    # Optional UI:
    path('api/documentation/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('add/property/', proForm, name='proForm'),
    path('add/tenant/', tenaForm, name='tenaForm'),
    path('add/unit/', unitForm, name='unitForm'),
    path('add/lease/', leaseForm, name='leaseForm'),
    path("properties/home/", home_views, name='home_views'),
    path("home/", home, name="home"),
    path('dashboard/admin/', admin_dashboard, name='admin_dashboard'),
    path('dashboard/landlord/', landlord_dashboard, name='landlord_dashboard'),
    path('dashboard/tenant/', tenant_dashboard, name='tenant_dashboard'),
    path('a/a/', proForm, name='proForm'),
    path('prop', prop, name='prop'),
    path('tena', ten, name='ten'),
    path('messages',messaging_view,name='messaging_view'),

    path('user-management/', user_management, name='user_management'),
    path('toggle-activation/<int:user_id>/', toggle_activation, name='toggle_activation'),
    path('toggle-admin/<int:user_id>/', toggle_admin, name='toggle_admin'),
    path('delete-user/<int:user_id>/', delete_user, name='delete_user'),
    path('add-user/', add_user, name='add_user'),
    #path('submit-request/', submit_request, name='submit_request'),
    #path('track-requests/', track_requests, name='track_requests'),
    path('add-user/', add_user, name='add_user'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    #path('tenant/<int:tenant_id>/edit/', edit_tenant, name='edit_tenant'),
    path("property_lists/", property_lists, name='property_lists'),
    path("tenant/", tenant_lists, name='tenant_lists'),
    path("lease_lists/", lease_lists, name='lease_lists'),
    path("edit_property/<int:property_id>/", edit_property, name='edit_property'),
    path("houseOneDetail/<int:property_id>/", houseOneDetails, name='houseOneDetail'),
    path('dashboard/properties/', property_dashboard, name='properties_dashboard'),
    path('dashboard/tenant/', tenant_dashboard, name='tenant_dashboard'),
    path('dashboard/tenant/message/', send_message_to_landlord, name='send_message_to_landlord'),
    path('tenant/<int:tenant_id>/edit/', edit_tenant, name='edit_tenant'),
    path('login/', login_user, name='login_user'),
    path('logout/', home, name='home'),
    path('register/', register, name='register'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
